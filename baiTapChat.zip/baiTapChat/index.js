const { disconnect } = require('process');

const app = require('express')();
const http = require('http').Server(app);
const io = require('socket.io')(http);
const port = process.env.PORT || 3500;

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/index.html');
});

var danhSachNguoiGui = []

var resBotChat = [
  "Xin chào",
  "Xin chào bạn nhé",
  "Chào buổi sáng, tôi có thể giúp gì cho bạn"
]
// io.on('connection', (socket) => {
//   danhSachNguoiGui.push({id: socket.id, soLanNoiBay: 0})
//   socket.on('chat message', msg => {
//     for ( let i = 0; i < danhSachNguoiGui.length; i ++) {
//       if(danhSachNguoiGui[i].id == socket.id){
//         let soLanNoiBayCuaNguoiHienTai = danhSachNguoiGui[i].soLanNoiBay



//         if (soLanNoiBayCuaNguoiHienTai < 3) {
//           if (msg == 'fuck you'){
//             io.emit('chat message', '***')
//             soLanNoiBayCuaNguoiHienTai ++
//             danhSachNguoiGui[i].soLanNoiBay = soLanNoiBayCuaNguoiHienTai
//           } 
//           else
//            {

//             let tam = ''
//             if (msg.length % 2 == 0) {
//               for (let i = msg.length - 1 ; i >= (msg.length - 1) / 2 ; i --){
//                 tam += (msg[i])

//               }
//               for (let i = 0; i <= (msg.length - 1) /2; i ++) {
//                 tam += (msg[i])
//               }
//               io.emit('chat message', tam )
//             } else {
//               for (let i = msg.length - 1 ; i >= ((msg.length + 1) / 2) - 1 ; i --){
//                 tam += (msg[i])

//               }
//               for (let i = 0; i <= ((msg.length - 1)  / 2) -1; i ++) {
//                 tam += (msg[i])
//               }
//               io.emit('chat message', tam )
//             }


//           }

//         }
//         else {

//           io.emit('chat message', {thongBao: "Tai khoan cua ban da bi khoa", idNguoiBiKhoa: socket.id})
//           danhSachNguoiGui[i].soLanNoiBay = 0
//         }
//       }
//     }
//   })
// })
// var str = "Anh yeu em";
// var res = str.replace("yeu", "<3");
// console.log(res)

io.on('connection', (socket) => {
  socket.on('chat message', msg => {
    var newMes = "";
            for (let i = 0; i < msg.length; i++) {
              if (msg[i] == 'y' ||msg[i] == 'Y' && msg[i + 1] == 'e' ||msg[i + 1] == 'ê' && msg[i + 2] == 'u' ) {
                newMes += '❤️';
                i += 2;
                
              } else {
                newMes += msg[i]
              }
    
            }
            io.emit("chat message", newMes);
    if (msg.includes("Xin chào")) {
      var a = Math.floor(Math.random() * resBotChat.length);
      io.emit('chat message', resBotChat[a]);
    }
    else {
      io.emit('chat message', "Tôi có thể giúp gì cho bạn?");
    }





  });
});








http.listen(port, () => {
  console.log(`Socket.IO server running at http://localhost:${port}/`);
});
